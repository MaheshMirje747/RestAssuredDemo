package objRepository;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

	public class ObjectRepoTest {
		RequestSpecification req;
		Response res;
		JsonPath data;
		File file;
		FileInputStream fis;
	
	@BeforeTest
	public void init() {
		RestAssured.baseURI="https://reqres.in/";
	}
	
	@Test
	public void addData() throws IOException {
		
		file = new File("C:\\Users\\SAGATAGI\\eclipse-workspace\\RestAssuredDemo\\src\\test\\java\\objRepository\\Postdata.properties");
		fis = new FileInputStream(file);
		Properties p = new Properties();
		p.load(fis);
		String name = p.getProperty("name");
		String job = p.getProperty("job");
		String name1 = p.getProperty("name1");
		String job1 = p.getProperty("job1");
		
		
		
	  	req = RestAssured.given();
	  	JSONObject obj = new JSONObject();
		obj.put("name", name);
		obj.put("job", job);
		obj.put("name1", name1);
		obj.put("job1", job1);
		req.headers("Content-Type","application/json");
		res = req.body(obj.toJSONString()).post("api/users");
		System.out.println(res.asPrettyString());
		Assert.assertEquals(res.getStatusCode(),201);
		data = res.jsonPath();
		
		String n=data.getString("name");
		System.out.println(n);
		Assert.assertEquals(n, name);
		
		String j=data.getString("job");
		System.out.println(j);
		Assert.assertEquals(j, job);
		
		String n1=data.getString("name1");
		System.out.println(n1);
		Assert.assertEquals(n1, name1);
		
		String j1=data.getString("job1");
		System.out.println(j1);
		Assert.assertEquals(j1, job1);
		
  }
  
  @AfterTest
  public void deallocateMem() {
	  req = null;
	  res = null;
	  data = null;
	  
  }
}
