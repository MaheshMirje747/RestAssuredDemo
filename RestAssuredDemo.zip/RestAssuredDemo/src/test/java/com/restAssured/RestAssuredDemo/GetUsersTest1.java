package com.restAssured.RestAssuredDemo;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetUsersTest1 {
	
	RequestSpecification req;
	Response res;
	JsonPath data;
	
	
	@BeforeTest
	public void init() {
		RestAssured.baseURI="https://reqres.in/";
	}
  @Test (priority = 0)
  public void getData() {
	  req = RestAssured.given();
	  res = req.get("api/users?page=2");
	  System.out.println(res.asString());
	  Assert.assertEquals(res.getStatusCode(),200);
	  
		 data=res.jsonPath();
		 
		 String page=data.getString("page");
		 System.out.println(page);
		 
		 String per_page=data.getString("per_page");
		 System.out.println(per_page);
		 
		 String total=data.getString("total");
		 System.out.println(total);
		 
		 String total_pages=data.getString("total_pages");
		 System.out.println(total_pages);
		 
		 String d=data.getString("data");
		 System.out.println(d);
		 
		 String id=data.getString("data[0].id");
		 System.out.println(id);
		 Assert.assertEquals(id, "7");
		 
		 String email=data.getString("data[0].email");
		 System.out.println(email);
		 Assert.assertEquals(email, "michael.lawson@reqres.in");
  }
  @Test (priority = 1)
  public void addData() {
	  	req = RestAssured.given();
	  	JSONObject obj = new JSONObject();
		obj.put("name", "vihaan");
		obj.put("job", "manager");
		req.headers("Content-Type","application/json");
		res = req.body(obj.toJSONString()).post("api/users");
		System.out.println(res.asPrettyString());
		Assert.assertEquals(res.getStatusCode(),201);
		data = res.jsonPath();
		String j=data.getString("job");
		System.out.println(j);
		Assert.assertEquals(j, "manager");
		String id1=data.getString("id");
		System.out.println(id1);
		Assert.assertEquals(id1, id1);
		
  }
  
  @AfterTest
  public void deallocateMem() {
	  req = null;
	  res = null;
	  data = null;
	  
  }
}
