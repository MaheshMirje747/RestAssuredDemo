package com.restAssured.RestAssuredDemo;

import static org.junit.Assert.assertTrue;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestLogSpecification;
import io.restassured.specification.RequestSpecification;

// import org.junit.Test;

public class AppTest 
{
    
   public static void main(String[] args) {
	   RestAssured.baseURI="https://reqres.in/";
	   RequestSpecification req = RestAssured.given();
	   
	   Response res = req.get("api/users?page=2");
	   System.out.println(res.asString());
	   System.out.println(res.asPrettyString());
	   System.out.println(res.statusCode());
	   System.out.println(res.getStatusLine());
	   
   }
   
}
