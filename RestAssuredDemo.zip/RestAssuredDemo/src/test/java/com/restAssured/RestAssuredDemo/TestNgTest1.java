package com.restAssured.RestAssuredDemo;

import org.testng.annotations.Test;

public class TestNgTest1 {
	
	@Test
	public void display() {
		System.out.println("Hello");
	}
	@Test
	public void show() {
		System.out.println("Welcome");
	}
}
