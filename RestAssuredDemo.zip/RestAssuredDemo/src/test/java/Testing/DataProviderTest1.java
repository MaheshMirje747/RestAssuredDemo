package Testing;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DataProviderTest1 {
		
		RequestSpecification req;
		Response res;
		JsonPath data;
		
		@DataProvider(name="CreateUser")
		public Object[][] getData()
		{
			Object[][] data = new Object[3][2];
			
			data[0][0] = "deppali";
			data[0][1] = "Consultant";
			
			data[1][0] = "kunal";
			data[1][1] = "Consultant";
			
			data[2][0] = "suraj";
			data[2][1] = "Sr.Engg";
			return data;
			
		}
		
		@BeforeTest
		public void init() {
			RestAssured.baseURI="https://reqres.in/";
		}
//	  @Test (priority = 0)
//	  public void getData() {
//		  req = RestAssured.given();
//		  res = req.get("api/users?page=2");
//		  System.out.println(res.asString());
//		  Assert.assertEquals(res.getStatusCode(),200);
//		  
//			 data=res.jsonPath();
//			 
//			 String page=data.getString("page");
//			 System.out.println(page);
//			 
//			 String per_page=data.getString("per_page");
//			 System.out.println(per_page);
//			 
//			 String total=data.getString("total");
//			 System.out.println(total);
//			 
//			 String total_pages=data.getString("total_pages");
//			 System.out.println(total_pages);
//			 
//			 String d=data.getString("data");
//			 System.out.println(d);
//			 
//			 String id=data.getString("data[0].id");
//			 System.out.println(id);
//			 Assert.assertEquals(id, "7");
//			 
//			 String email=data.getString("data[0].email");
//			 System.out.println(email);
//			 Assert.assertEquals(email, "michael.lawson@reqres.in");
//	  }
	  @Test(dataProvider="CreateUser") 
	  public void addData(String name, String job) {
		  	req = RestAssured.given();
		  	JSONObject obj = new JSONObject();
			obj.put("name", name);
			obj.put("job", job);
			req.headers("Content-Type","application/json");
			res = req.body(obj.toJSONString()).post("api/users");
			System.out.println(res.asPrettyString());
			Assert.assertEquals(res.getStatusCode(),201);
			data = res.jsonPath();
			
			String n=data.getString("name");
			System.out.println(n);
			Assert.assertEquals(n, name);
			
			String j=data.getString("job");
			System.out.println(j);
			Assert.assertEquals(j, job);
			
			
	  }
	  
	  @AfterTest
	  public void deallocateMem() {
		  req = null;
		  res = null;
		  data = null;
		  
	  }
}


