package Testing;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.junit.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

	public class ExcelReaderTest1 {
		RequestSpecification req;
		Response res;
		JsonPath data;
		File file;
		FileInputStream fis;
//		XSSFWorkbook w;
		Workbook w;
//		XSSFSheet s;
		Sheet s;
	
	@BeforeTest
	public void init() {
		RestAssured.baseURI="https://reqres.in/";
	}
	
	@Test
	public void addData() throws IOException {
		
		file = new File("C:\\Users\\SAGATAGI\\eclipse-workspace\\RestAssuredDemo\\src\\test\\resource\\ExcelData\\Data1.xlsx");
		fis = new FileInputStream(file);
		w = new XSSFWorkbook(fis);
		
		// get the sheet by index
		// s = w.getSheetAt(0);
		
		// get the sheet by name
		s = w.getSheet("Data1");
		
		int row = s.getPhysicalNumberOfRows();
		System.out.println("Rows: "+row);
		int col = s.getRow(0).getPhysicalNumberOfCells();
		System.out.println("cols: "+col);
		String name = s.getRow(0).getCell(0).toString();
		String job = s.getRow(0).getCell(1).getStringCellValue();
		
		
	  	req = RestAssured.given();
	  	JSONObject obj = new JSONObject();
		obj.put("name", name);
		obj.put("job", job);
//		obj.put("name1", name1);
//		obj.put("job1", job1);
		req.headers("Content-Type","application/json");
		res = req.body(obj.toJSONString()).post("api/users");
		System.out.println(res.asPrettyString());
		Assert.assertEquals(res.getStatusCode(),201);
		data = res.jsonPath();
		
		String n=data.getString("name");
		System.out.println(n);
		Assert.assertEquals(n, name);
		
		String j=data.getString("job");
		System.out.println(j);
		Assert.assertEquals(j, job);
		
//		String n1=data.getString("name1");
//		System.out.println(n1);
//		Assert.assertEquals(n1, name1);
//		
//		String j1=data.getString("job1");
//		System.out.println(j1);
//		Assert.assertEquals(j1, job1);
		
  }
  
  @AfterTest
  public void deallocateMem() {
	  req = null;
	  res = null;
	  data = null;
	  
  }
}
